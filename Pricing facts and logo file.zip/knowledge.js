// YaratSlayd AI yordamchi — knowledge layer.
// Service boundary: replace `retrieve()` with a call to the real AI/RAG endpoint.
// Every entry is either status:"verified" (fact observed in the product) or
// status:"unavailable" (no authoritative source supplied — the assistant must NOT guess).

export const CATEGORIES = {
  PRODUCT: { uz: "Mahsulot", ru: "Продукт", en: "Product" },
  FEATURES: { uz: "Imkoniyatlar", ru: "Возможности", en: "Features" },
  PRICING: { uz: "Narxlar", ru: "Тарифы", en: "Pricing" },
  CREDITS: { uz: "Kreditlar", ru: "Кредиты", en: "Credits" },
  PAYMENTS: { uz: "To‘lov", ru: "Оплата", en: "Payments" },
  PPTX: { uz: "PPTX", ru: "PPTX", en: "PPTX" },
  TEMPLATES: { uz: "Shablonlar", ru: "Шаблоны", en: "Templates" },
  ACCOUNT: { uz: "Akkaunt", ru: "Аккаунт", en: "Account" },
  TELEGRAM: { uz: "Telegram", ru: "Telegram", en: "Telegram" },
  TROUBLE: { uz: "Texnik muammo", ru: "Технические проблемы", en: "Troubleshooting" }
};

export const UNAVAILABLE_UZ = "Bu ma’lumot menda mavjud emas.";

// Escalation channels. Nothing is invented: `handle` stays null until backend supplies it.
export const CHANNELS = [
  { id: "telegram", label: "Telegram operator", handle: null, note: "Kanal hali ulanmagan (backend)" },
  { id: "ticket", label: "Support ticket", handle: null, note: "Endpoint hali ulanmagan (backend)" },
  { id: "email", label: "Email", handle: null, note: "Manzil hali kiritilmagan" }
];

export const KB = [
  {
    id: "create",
    category: "PRODUCT",
    status: "verified",
    keywords: ["taqdimot", "yarat", "qanday", "boshla", "slayd son", "mavzu", "create", "создать"],
    a: "Creator oynasida mavzuni yozasiz, so‘ng tilni, taqdimot turini va slaydlar sonini tanlaysiz. AI tuzilma, matn va dizaynni tayyorlaydi. Natijani Workspace’da ko‘rib chiqasiz.",
    actions: [{ id: "creator", label: "Taqdimot yaratish" }]
  },
  {
    id: "plan",
    category: "FEATURES",
    status: "verified",
    keywords: ["reja", "tuzilma", "struktura", "plan", "план"],
    a: "Taqdimot rejasini alohida ham tuzish mumkin: mavzu bo‘yicha sarlavha, bo‘limlar va matn tuzilmasi tayyorlanadi.",
    actions: [{ id: "creator", label: "Reja tuzish" }]
  },
  {
    id: "pptx",
    category: "PPTX",
    status: "verified",
    keywords: ["pptx", "powerpoint", "yuklab", "download", "eksport", "скачать", "fayl"],
    a: "Tayyor taqdimotni Workspace ichida ochib, “PowerPoint yuklab olish” tugmasini bosasiz. Fayl haqiqiy .pptx formatida saqlanadi va PowerPoint’da ochiladi.",
    actions: [
      { id: "workspace", label: "Workspace’ni ochish" },
      { id: "pptx", label: "PPTX yuklab olish" }
    ]
  },
  {
    id: "edit",
    category: "FEATURES",
    status: "verified",
    keywords: ["tahrir", "o‘zgartir", "ozgartir", "slaydni", "qisqartir", "qayta yarat", "dizayn", "edit"],
    a: "Workspace’da slaydlarni tahrirlash, o‘chirish va qayta yaratish mumkin. Matnni qisqartirish yoki dizaynni o‘zgartirish ham shu oynada bajariladi.",
    actions: [{ id: "workspace", label: "Workspace’ni ochish" }]
  },
  {
    id: "translate",
    category: "FEATURES",
    status: "verified",
    keywords: ["tarjima", "til", "перевод", "translate", "rus", "ingliz"],
    a: "Tayyor taqdimotni boshqa tilga tarjima qilish mumkin. Tilni Creator’da taqdimot yaratishdan oldin ham tanlaysiz.",
    actions: [{ id: "creator", label: "Creator’ni ochish" }]
  },
  {
    id: "templates",
    category: "TEMPLATES",
    status: "partial",
    keywords: ["shablon", "template", "dizayn to‘plami", "шаблон", "premium"],
    a: "Shablonlar standart va premium turlarga bo‘linadi — Biznes, Ta’lim va maxsus to‘plamlar mavjud.",
    gap: "Qaysi shablon qaysi tarifda ochilishi bo‘yicha aniq ma’lumot menda yo‘q.",
    actions: [
      { id: "templates", label: "Shablonlarni ko‘rish" },
      { id: "operator", label: "Operator bilan bog‘lanish" }
    ]
  },
  {
    id: "credits",
    category: "CREDITS",
    status: "unavailable",
    keywords: ["kredit", "credit", "кредит", "limit", "qancha slayd"],
    actions: [{ id: "pricing", label: "Narxlar sahifasi" }, { id: "operator", label: "Operator bilan bog‘lanish" }]
  },
  {
    id: "pricing",
    category: "PRICING",
    status: "unavailable",
    keywords: ["narx", "tarif", "obuna", "pul", "price", "цена", "qancha turadi", "bepul"],
    actions: [{ id: "pricing", label: "Narxlar sahifasi" }, { id: "operator", label: "Operator bilan bog‘lanish" }]
  },
  {
    id: "payments",
    category: "PAYMENTS",
    status: "unavailable",
    keywords: ["to‘lov", "tolov", "karta", "click", "payme", "оплата", "hisob", "invoys"],
    actions: [{ id: "operator", label: "Operator bilan bog‘lanish" }]
  },
  {
    id: "refund",
    category: "PAYMENTS",
    status: "unavailable",
    keywords: ["qaytar", "refund", "возврат", "bekor qil"],
    actions: [{ id: "operator", label: "Operator bilan bog‘lanish" }]
  },
  {
    id: "account",
    category: "ACCOUNT",
    status: "unavailable",
    keywords: ["akkaunt", "profil", "parol", "kirish", "ro‘yxatdan", "аккаунт", "login"],
    actions: [{ id: "account", label: "Akkaunt sahifasi" }, { id: "operator", label: "Operator bilan bog‘lanish" }]
  },
  {
    id: "telegram",
    category: "TELEGRAM",
    status: "unavailable",
    keywords: ["telegram", "bot", "kanal"],
    actions: [{ id: "operator", label: "Operator bilan bog‘lanish" }]
  },
  {
    id: "download-error",
    category: "TROUBLE",
    status: "verified",
    keywords: ["xatolik", "ishlamayapti", "yuklanmadi", "ochilmadi", "error", "ошибка", "muammo"],
    a: "Avval yuklab olishni qayta urinib ko‘ring va sahifani yangilang. Muammo takrorlansa, taqdimot nomi va vaqtini operatorga yuboring — u loglar bo‘yicha tekshiradi.",
    actions: [{ id: "operator", label: "Operator bilan bog‘lanish" }]
  }
];

export const CONTEXT_SUGGESTIONS = {
  landing: ["create", "pricing", "templates"],
  creator: ["create", "plan", "credits"],
  workspace: ["pptx", "edit", "download-error"],
  templates: ["templates", "pricing"],
  pricing: ["pricing", "credits", "payments"],
  account: ["account", "payments", "credits"]
};

function norm(s) {
  return (s || "")
    .toLowerCase()
    .replace(/[’‘ʻʼ`']/g, "‘")
    .replace(/\s+/g, " ")
    .trim();
}

export function retrieve(query) {
  const q = norm(query);
  if (!q) return null;
  let best = null;
  let bestScore = 0;
  for (const e of KB) {
    let score = 0;
    for (const k of e.keywords) {
      const kk = norm(k);
      if (q.includes(kk)) score += kk.length > 5 ? 3 : 2;
    }
    if (score > bestScore) {
      bestScore = score;
      best = e;
    }
  }
  return bestScore >= 2 ? best : null;
}

export function answerFor(entry) {
  if (!entry) {
    return {
      text: UNAVAILABLE_UZ + " Aniq javob berish uchun operatorga ulanishim mumkin.",
      status: "unavailable",
      actions: [{ id: "operator", label: "Operator bilan bog‘lanish" }]
    };
  }
  if (entry.status === "unavailable") {
    return {
      text: UNAVAILABLE_UZ + " Noto‘g‘ri raqam yoki shart aytmaslik uchun taxmin qilmayman — operator aniq javob beradi.",
      status: "unavailable",
      actions: entry.actions || []
    };
  }
  return {
    text: entry.status === "partial" ? entry.a + "\n" + entry.gap : entry.a,
    status: entry.status,
    actions: entry.actions || []
  };
}
