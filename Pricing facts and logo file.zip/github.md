repo: ssherqobilogli-star/slayd-BOT-KIWI
branch: main

## Last sync
date: 2026-09-06T00:00:00Z
note: repository returned no importable files at main — nothing could be read or copied.

### Updated in this project
- Built "AI Yordamchi.dc.html": floating launcher, morphing assistant panel, chat, quick actions, escalation and error states.
- Design tokens reconstructed from the uploaded production build (Inter, slate neutrals, indigo→blue→violet gradient).
- Brand mark extracted from the uploaded logo sheet into assets/mark-color.png and assets/mark-white.png.
- knowledge.js added as the knowledge/service layer; unsupplied facts answer "Bu ma'lumot menda mavjud emas."

## Screen map
| Project screen | Source |
| --- | --- |
| AI Yordamchi.dc.html | uploads/YaratSlayd_AI-1.html (built bundle), uploads logo sheet |
| knowledge.js | product copy observed in the uploaded bundle |
